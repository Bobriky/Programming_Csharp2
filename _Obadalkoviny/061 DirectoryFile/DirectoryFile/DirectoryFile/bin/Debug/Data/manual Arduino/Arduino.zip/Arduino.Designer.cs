﻿namespace $safeprojectname$
{
    partial class $safeprojectname$
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof($safeprojectname$));
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.souborToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.konecToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.portToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenCloseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.comStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.comBtnPort = new System.Windows.Forms.ToolStripButton();
            this.comCmbNumber = new System.Windows.Forms.ToolStripComboBox();
            this.comLblSpeed = new System.Windows.Forms.ToolStripLabel();
            this.comCmbSpeed = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.comBtnOpenClose = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.comBtnReset = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.comBtnEnd = new System.Windows.Forms.ToolStripButton();
            this.showDataRX = new System.Windows.Forms.ToolStripStatusLabel();
            this.showDataTX = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblDataRX = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblDataTX = new System.Windows.Forms.ToolStripStatusLabel();
            this.oProgramuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nápovědaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.readCOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showDataRXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showDataTXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.souborToolStripMenuItem,
            this.portToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(536, 24);
            this.menuStrip1.TabIndex = 26;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // souborToolStripMenuItem
            // 
            this.souborToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showDataRXToolStripMenuItem,
            this.showDataTXToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.toolStripSeparator1,
            this.konecToolStripMenuItem});
            this.souborToolStripMenuItem.Name = "souborToolStripMenuItem";
            this.souborToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.souborToolStripMenuItem.Text = "&File";
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.saveAsToolStripMenuItem.Text = "Save As";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(151, 6);
            // 
            // konecToolStripMenuItem
            // 
            this.konecToolStripMenuItem.Name = "konecToolStripMenuItem";
            this.konecToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.konecToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.konecToolStripMenuItem.Text = "Konec";
            this.konecToolStripMenuItem.Click += new System.EventHandler(this.comBtnEnd_Click);
            // 
            // portToolStripMenuItem
            // 
            this.portToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.readCOMToolStripMenuItem,
            this.OpenCloseMenuItem,
            this.resetToolStripMenuItem});
            this.portToolStripMenuItem.Name = "portToolStripMenuItem";
            this.portToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.portToolStripMenuItem.Text = "&Port";
            // 
            // OpenCloseMenuItem
            // 
            this.OpenCloseMenuItem.Checked = true;
            this.OpenCloseMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.OpenCloseMenuItem.Name = "OpenCloseMenuItem";
            this.OpenCloseMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.OpenCloseMenuItem.Size = new System.Drawing.Size(186, 22);
            this.OpenCloseMenuItem.Text = "&Open / Close";
            this.OpenCloseMenuItem.Click += new System.EventHandler(this.comBtnOpenClose_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oProgramuToolStripMenuItem,
            this.nápovědaToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel3,
            this.comStatus,
            this.showDataTX,
            this.lblDataTX,
            this.showDataRX,
            this.lblDataRX});
            this.statusStrip1.Location = new System.Drawing.Point(0, 324);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(536, 22);
            this.statusStrip1.TabIndex = 27;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(60, 17);
            this.toolStripStatusLabel3.Text = "  Status     ";
            // 
            // comStatus
            // 
            this.comStatus.BackColor = System.Drawing.Color.Lime;
            this.comStatus.Name = "comStatus";
            this.comStatus.Size = new System.Drawing.Size(65, 17);
            this.comStatus.Text = "ComStatus";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comBtnPort,
            this.comCmbNumber,
            this.comLblSpeed,
            this.comCmbSpeed,
            this.toolStripSeparator2,
            this.comBtnOpenClose,
            this.toolStripLabel1,
            this.toolStripSeparator3,
            this.comBtnReset,
            this.toolStripSeparator4,
            this.comBtnEnd});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(536, 25);
            this.toolStrip1.TabIndex = 28;
            this.toolStrip1.Text = "PanelTool";
            // 
            // comBtnPort
            // 
            this.comBtnPort.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.comBtnPort.Image = ((System.Drawing.Image)(resources.GetObject("comBtnPort.Image")));
            this.comBtnPort.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.comBtnPort.Name = "comBtnPort";
            this.comBtnPort.Size = new System.Drawing.Size(43, 22);
            this.comBtnPort.Text = "  Read";
            this.comBtnPort.Click += new System.EventHandler(this.comBtnPort_Click);
            // 
            // comCmbNumber
            // 
            this.comCmbNumber.Name = "comCmbNumber";
            this.comCmbNumber.Size = new System.Drawing.Size(75, 25);
            this.comCmbNumber.Sorted = true;
            this.comCmbNumber.Click += new System.EventHandler(this.comCmbNumber_Click);
            // 
            // comLblSpeed
            // 
            this.comLblSpeed.Name = "comLblSpeed";
            this.comLblSpeed.Size = new System.Drawing.Size(51, 22);
            this.comLblSpeed.Text = "    Speed";
            // 
            // comCmbSpeed
            // 
            this.comCmbSpeed.Items.AddRange(new object[] {
            "300",
            "1200",
            "2400",
            "4800",
            "9600",
            "19200",
            "38400",
            "57600",
            "74880",
            "115200"});
            this.comCmbSpeed.Name = "comCmbSpeed";
            this.comCmbSpeed.Size = new System.Drawing.Size(75, 25);
            this.comCmbSpeed.Click += new System.EventHandler(this.comCmbSpeed_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // comBtnOpenClose
            // 
            this.comBtnOpenClose.AutoSize = false;
            this.comBtnOpenClose.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.comBtnOpenClose.Image = ((System.Drawing.Image)(resources.GetObject("comBtnOpenClose.Image")));
            this.comBtnOpenClose.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.comBtnOpenClose.Name = "comBtnOpenClose";
            this.comBtnOpenClose.Size = new System.Drawing.Size(80, 22);
            this.comBtnOpenClose.Text = "Open";
            this.comBtnOpenClose.Click += new System.EventHandler(this.comBtnOpenClose_Click);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(58, 22);
            this.toolStripLabel1.Text = "                 ";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // comBtnReset
            // 
            this.comBtnReset.AutoSize = false;
            this.comBtnReset.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.comBtnReset.Image = ((System.Drawing.Image)(resources.GetObject("comBtnReset.Image")));
            this.comBtnReset.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.comBtnReset.Name = "comBtnReset";
            this.comBtnReset.Size = new System.Drawing.Size(50, 22);
            this.comBtnReset.Text = "Reset";
            this.comBtnReset.Click += new System.EventHandler(this.comBtnReset_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // comBtnEnd
            // 
            this.comBtnEnd.AutoSize = false;
            this.comBtnEnd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.comBtnEnd.Image = ((System.Drawing.Image)(resources.GetObject("comBtnEnd.Image")));
            this.comBtnEnd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.comBtnEnd.Name = "comBtnEnd";
            this.comBtnEnd.Size = new System.Drawing.Size(60, 22);
            this.comBtnEnd.Text = "End";
            this.comBtnEnd.Click += new System.EventHandler(this.comBtnEnd_Click);
            // 
            // showDataRX
            // 
            this.showDataRX.BackColor = System.Drawing.SystemColors.Control;
            this.showDataRX.Name = "showDataRX";
            this.showDataRX.Size = new System.Drawing.Size(66, 17);
            this.showDataRX.Text = "    Data &RX: ";
            // 
            // showDataTX
            // 
            this.showDataTX.BackColor = System.Drawing.SystemColors.Control;
            this.showDataTX.Name = "showDataTX";
            this.showDataTX.Size = new System.Drawing.Size(101, 17);
            this.showDataTX.Text = "                Data &TX: ";
            // 
            // lblDataRX
            // 
            this.lblDataRX.AutoSize = false;
            this.lblDataRX.BackColor = System.Drawing.SystemColors.Control;
            this.lblDataRX.Name = "lblDataRX";
            this.lblDataRX.Size = new System.Drawing.Size(100, 17);
            this.lblDataRX.Text = "receive";
            // 
            // lblDataTX
            // 
            this.lblDataTX.AutoSize = false;
            this.lblDataTX.BackColor = System.Drawing.SystemColors.Control;
            this.lblDataTX.Name = "lblDataTX";
            this.lblDataTX.Size = new System.Drawing.Size(100, 17);
            this.lblDataTX.Text = "transmit";
            // 
            // oProgramuToolStripMenuItem
            // 
            this.oProgramuToolStripMenuItem.Name = "oProgramuToolStripMenuItem";
            this.oProgramuToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.oProgramuToolStripMenuItem.Text = "O programu";
            this.oProgramuToolStripMenuItem.Click += new System.EventHandler(this.oProgramuToolStripMenuItem_Click);
            // 
            // nápovědaToolStripMenuItem
            // 
            this.nápovědaToolStripMenuItem.Name = "nápovědaToolStripMenuItem";
            this.nápovědaToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.nápovědaToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.nápovědaToolStripMenuItem.Text = "Nápověda";
            this.nápovědaToolStripMenuItem.Click += new System.EventHandler(this.nápovědaToolStripMenuItem_Click);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.comBtnReset_Click);
            // 
            // readCOMToolStripMenuItem
            // 
            this.readCOMToolStripMenuItem.Name = "readCOMToolStripMenuItem";
            this.readCOMToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.readCOMToolStripMenuItem.Text = "Read COM";
            this.readCOMToolStripMenuItem.Click += new System.EventHandler(this.comBtnPort_Click);
            // 
            // showDataRXToolStripMenuItem
            // 
            this.showDataRXToolStripMenuItem.Checked = true;
            this.showDataRXToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.showDataRXToolStripMenuItem.Name = "showDataRXToolStripMenuItem";
            this.showDataRXToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.showDataRXToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.showDataRXToolStripMenuItem.Text = "Show Data &RX";
            this.showDataRXToolStripMenuItem.Click += new System.EventHandler(this.showDataRXToolStripMenuItem_Click);
            // 
            // showDataTXToolStripMenuItem
            // 
            this.showDataTXToolStripMenuItem.Checked = true;
            this.showDataTXToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.showDataTXToolStripMenuItem.Name = "showDataTXToolStripMenuItem";
            this.showDataTXToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.showDataTXToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.showDataTXToolStripMenuItem.Text = "Show Data &TX";
            this.showDataTXToolStripMenuItem.Click += new System.EventHandler(this.showDataTXToolStripMenuItem_Click);
            // 
            // $safeprojectname$
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(536, 346);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "$safeprojectname$";
            this.Text = "$safeprojectname$";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem souborToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem portToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OpenCloseMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem konecToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel comStatus;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton comBtnPort;
        private System.Windows.Forms.ToolStripComboBox comCmbNumber;
        private System.Windows.Forms.ToolStripLabel comLblSpeed;
        private System.Windows.Forms.ToolStripComboBox comCmbSpeed;
        private System.Windows.Forms.ToolStripButton comBtnOpenClose;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton comBtnReset;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton comBtnEnd;
        private System.Windows.Forms.ToolStripStatusLabel showDataTX;
        private System.Windows.Forms.ToolStripStatusLabel showDataRX;
        private System.Windows.Forms.ToolStripStatusLabel lblDataRX;
        private System.Windows.Forms.ToolStripStatusLabel lblDataTX;
        private System.Windows.Forms.ToolStripMenuItem oProgramuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nápovědaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showDataRXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showDataTXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem readCOMToolStripMenuItem;
    }
}

