# Arduino_MultiFunctionShield
LED Display driver for Multi Function Shield

**Note:** Timer1 used => Pins 9 and 10 on Uno for PWM and analogWrite() are effected

![multi_function_shield](multi_function_shield.png?raw=true)

Fritzing Part: [Download Multi Function Shield](https://www.heise.de/make/downloads/76/2/4/1/3/8/7/4/Multi_Function_Shield.fzpz)

https://www.blafusel.de/index.html
