﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace $safeprojectname$
{
    public partial class $safeprojectname$ : Form
    {
        public $safeprojectname$()
        {
            InitializeComponent();
            InitApp();
        }

        private void InitApp()
        {
            comStav(false);
            comBtnReset.Enabled = false;
            showPortCom();
            comCmbSpeed.SelectedIndex = 4;
            lblDataTX.Text = "transmit";
            lblDataRX.Text = "receive";
        }

        private void showPortCom()
        {
            comCmbNumber.Items.Clear();
            comCmbNumber.Items.AddRange(SerialPort.GetPortNames());
            if (comCmbNumber.Items.Count > 0)
            {
                comCmbNumber.SelectedIndex = comCmbNumber.Items.Count - 1;
            }
        }

        /* COM panel */
        private void comBtnPort_Click(object sender, EventArgs e)
        {
            InitApp();
        }

        private void comCmbNumber_Click(object sender, EventArgs e)
        {
            comBtnReset.Enabled = true;
        }

        private void comCmbSpeed_Click(object sender, EventArgs e)
        {
            comBtnReset.Enabled = true;
        }

        private void comBtnOpenClose_Click(object sender, EventArgs e)
        {
            comBtnReset.Enabled = true;
            if (comBtnOpenClose.Text == "Open")
            {
                comStav(true);
                comOpen();
            }
            else
            {
                comStav(false);
                comClose();
            }
        }

        private void comBtnReset_Click(object sender, EventArgs e)
        {
            comClose();
            InitApp();
        }

        private void comBtnEnd_Click(object sender, EventArgs e)
        {
            comClose();
            Close();
        }

        /* COM control */
        private void comOpen()
        {
            try
            {
                serialPort1.PortName = comCmbNumber.Text;
                serialPort1.BaudRate = Convert.ToInt32(comCmbSpeed.Text);
                serialPort1.Open();
            }
            catch (Exception chyba)
            {
                lblDataTX.Text = chyba.Message;
                comStav(false);
            }

        }

        private void comClose()
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    lblDataTX.Text = "transmit";
                    lblDataRX.Text = "receive";
                    serialPort1.Close();
                }
                catch (Exception chyba)
                {
                    lblDataTX.Text = chyba.Message;
                }
            }
        }

        private void comStav(bool iStatus)
        {
            if (iStatus)
            {
                comStatus.Text = "Connected";
                comStatus.BackColor = Color.LightGreen;
                comBtnOpenClose.Text = "Close";
                comBtnPort.Enabled = false;
                comCmbNumber.Enabled = false;
                comCmbSpeed.Enabled = false;
                OpenCloseMenuItem.Text = "Close";
            }
            else
            {
                comStatus.Text = "Disconnected";
                comStatus.BackColor = Color.PaleVioletRed;
                comBtnOpenClose.Text = "Open";
                comBtnPort.Enabled = true;
                comCmbNumber.Enabled = true;
                comCmbSpeed.Enabled = true;
                OpenCloseMenuItem.Text = "Open";
            }
        }

        private void showDataRXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showDataRXToolStripMenuItem.Checked = !showDataRXToolStripMenuItem.Checked;
            if (showDataRXToolStripMenuItem.Checked)
            {
                lblDataRX.Visible = true;
                showDataRX.Visible = true;
            }
            else
            {
                lblDataRX.Visible = false;
                showDataRX.Visible = false;
            }
        }

        private void showDataTXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showDataTXToolStripMenuItem.Checked = !showDataTXToolStripMenuItem.Checked;
            if (showDataTXToolStripMenuItem.Checked)
            {
                lblDataTX.Visible = true;
                showDataTX.Visible = true;
            }
            else
            {
                lblDataTX.Visible = false;
                showDataTX.Visible = false;
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        /* Help */
        private void oProgramuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("SŠE Lipník nad Bečvou", "$safeprojectname$", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void nápovědaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String  textSMS = "-------------------------------------------\n";
                    textSMS += " 1. Výběr a připojení COM\n";
                    textSMS += " 2. Funkce pro zasání dat:\n";
                    textSMS += "   void comDataWrite(stringiCmd, bool iEndLine)\n";
                    textSMS += "   iCmd - zasílaný příkaz\n";
                    textSMS += "   iEndLine - true: ukončen řádek, false: neukončen řádek\n";
            MessageBox.Show("Nápověda k použití programu.\n" + textSMS, "Help", MessageBoxButtons.OK, MessageBoxIcon.Question);
        }

        /* COM data*/
        public string dataRX;

        private void comDataWrite(string iCmd, bool iEndLine)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    if (iEndLine)
                    {
                        serialPort1.WriteLine(iCmd);
                    }
                    else
                    {
                        serialPort1.Write(iCmd);
                    }
                    lblDataTX.Text = iCmd;
                }
                catch (Exception chyba)
                {
                    lblDataTX.Text = chyba.Message;
                }
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            //serialData = serialPort1.ReadExisting();
            try
            {
                dataRX = serialPort1.ReadLine();
                this.Invoke(new EventHandler(comDataWork));
            }
            catch 
            {
                
            }
        }

        private void comDataWork(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                lblDataTX.Text = dataRX;
                try
                {
                    receivedData(dataRX);
                }
                catch (Exception chyba)
                {
                    lblDataTX.Text = chyba.Message;
                }
            }
        }
        /* Metoda pro zpracování prijatých dat z Arduina */
        private void receivedData(string iData)
        {
            /* */
        }

        /* Vlastní aplikace pro řízení Arduina */


    }
}
